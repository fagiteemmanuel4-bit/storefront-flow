# Strap redesign — Feature map

**Repository:** `fagiteemmanuel4-bit/storefront-flow`  
**Audited ref:** `main`  
**Purpose:** preserve every existing capability while migrating presentation. This is a route-level map; each module must be re-audited for nested tabs, dialogs, sheets, conditional sections and role/plan states before styling.

| Feature area | Existing entry screens/routes | Supporting components / notes |
|---|---|---|
| Authentication and account access | `/auth`, `/signup`, `/verify-email`, `/verified`, `/email-confirmed` | Supabase auth, existing sign-in/sign-up modes, eight-digit OTP, resend cooldown, redirects and error handling. |
| Merchant onboarding | `/onboarding` | Authenticated route guard and `StoreProvider`; preserve store creation and membership setup. |
| Dashboard / business overview | `/dashboard` | Sales, revenue, low-stock, online-order and business-mode summaries; quick actions. |
| Point of sale / register | `/pos`, `/unit-sale` | Product grid/search, cart, quantities, discounts, customer, payment, pack/unit pricing, checkout, offline queue, scanner, calculator and receipt handoff. |
| Products / catalogue | `/products`, `/product-import` | `ProductFormDialog`, `ProductImportDialog`; product data, SKU, barcode, category, image, shelf, variants, cost/price, threshold and branch stock. |
| Inventory / stock management | `/products`, `/stock-sense`, `/grocery-inventory`, `/settings/inventory` | Branch stock, low-stock thresholds, batch/expiry, pack/piece quantities, stock sheet parsing/import and inventory preferences. |
| Orders / fulfilment | `/online-store/orders`, `/track/$token`, public storefront product/order flows | Online order list, status actions, tracking tokens and customer order tracking. Preserve order state transitions. |
| Customers / loyalty / credit | `/customers`, `/customer-account`, `/pos` | Customer records, segments, visit/spend history, credit and checkout customer selection. |
| Expenses | `/expenses` | `AddExpenseSheet`, expense category/date/search, edit/delete and confirmation flows. |
| Reports / analytics | `/reports`, `/insights`, `/command-center` | Revenue/expense/profit, payment mix, top products, business insights and operational actions. |
| Activity / audit history | `/activity`, shell activity/notification surfaces | Persistent activity history and audit context; keep existing access and retention behavior. |
| Notifications | `/notifications`, `/settings/notifications`, shell menu/header | Operational notifications and preference controls. |
| Branches / multi-location | `/branches`, shell store/branch selector, `/settings/inventory` | Branch creation, default branch, branch-aware stock and POS context. |
| Team / roles / staff access | `/staff`, `/settings/staff`, `/staff-login/$slug` | Owner/manager/cashier roles, staff sessions, PIN/access links, role-filtered navigation and permission redirects. |
| Online store / storefront setup | `/online-store`, `/online-store/setup`, `/settings/online-store` | Store profile, publish/setup state, SEO/catalog visibility, domain settings and storefront management. |
| Storefront builder / editor | `/online-store/builder`, `/online-store/advanced-editor`, `/store-editor` | Template/editor controls, custom domains, appearance and storefront configuration. |
| Online catalogue / public shop | `/online-store/catalog`, `/store/$slug`, `/store/$slug/category/$category`, `/store/$slug/products/$productSlug` | Customer-facing catalogue, category pages and product detail pages. |
| Business modes / specialist workspaces | `/electronics-workspace`, `/fashion-returns`, `/food-service`, `/grocery-inventory` | Conditional workspace/navigation for electronics, fashion, food-service and grocery/provision stores. |
| Wholesale / pack and unit sales | `/unit-sale`, `/pos`, `/products` | Pack pricing, units per pack, piece pricing and relevant checkout/product controls; no standalone wholesale route found in the audited route tree. |
| Receipt designer / receipt settings | `/receipt-designer`, `/settings/receipts`, POS checkout | Designer preview/settings, receipt preferences and print/share actions. **Do not restyle receipt output, printer templates or exports.** |
| Hardware / scanners / printers | `/hardware`, `/pos`, `/products` | Camera barcode/QR scanner, keyboard-wedge scanner, Bluetooth/serial printer/device support and connection capability states. |
| Software integrations / extensions | `/extensions`, `/settings/advanced` and relevant settings sections | Extension catalogue and integration surfaces; inspect all enabled connectors and status states before migrating. |
| Store and account settings | `/settings`, `/settings/store-profile`, `/settings/appearance`, `/settings/checkout`, `/settings/inventory`, `/settings/notifications`, `/settings/online-store`, `/settings/payments`, `/settings/security`, `/settings/password`, `/settings/sessions`, `/settings/sessions/revoke`, `/settings/staff` | `SettingsCenter`, `SettingsShell`, settings child components and role-gated actions. Settings home also declares an advanced section. |
| Plans / billing | `/upgrade` | Plan access and premium/feature notices; preserve pricing, entitlements and paid-area guards. |
| Help / support / documentation | `/help`, `/support`, `/docs` | In-app help, support and product documentation. |
| Search / quick find | Shell header trigger, `QuickFind`; mobile dock Search action | There is no standalone `/search` route. Search is a shared shell interaction; preserve keyboard shortcuts and all existing search scopes. |
| App navigation / store context | `AppShell`, `MobileNav`, `AppMenuSheet`, `StoreProvider` | Store/branch switching, mode-aware nav, staff role filters, offline queue, online/offline status, updates, calculator, security and sign-out. |
| Data export / destructive store actions | Menu actions | `ExportDataDialog`, `DeleteStoreDialog`; preserve confirmations, export format and authorization. |
| Public company and legal pages | `/`, `/about`, `/partners`, `/privacy`, `/terms`, `/cookies` | Public landing/marketing and legal pages; scope of redesign needs confirmation. |
| Admin | `/admin` | Separate admin surface; verify access/role requirements before including in visual migration. |

## Navigation preservation checklist

The new four mobile destinations are **Sell**, **Products**, **Search**, and **Menu**. These are visual entry points, not permission changes:
- Sell → `/pos` (preserve mode-aware Sell/alternate workspace affordances).
- Products → `/products` (mode-specific catalogue labels remain contextual).
- Search → existing `QuickFind` interaction (no route change).
- Menu → every remaining existing destination and action, respecting current role, plan, business-mode and staff-session filtering.

Desktop/tablet navigation must preserve the same destinations in the sidebar. Do not flatten away the current mode-aware navigation or expose hidden links to roles that cannot access them. Preserve store/branch switching, online/offline indicators, queued sale status, updates, notifications, security, calculator and sign-out.

## Feature-map validation required during implementation

For each module, compare this map with the actual rendered page and source before restyling:
1. Enumerate every visible control, nested tab, filter, sort, bulk action, modal, sheet, confirmation and empty/error/loading state.
2. Record every role/permission/plan condition and every business-mode conditional.
3. Confirm every action still calls the same handler and every form submits the same payload.
4. Keep keyboard scanner focus/capture, camera permissions, printer connections, exports and print layouts behaviorally unchanged.
5. Update this map if source inspection finds an additional capability; never delete a capability to make the new design fit.
